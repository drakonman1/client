import React, { useState, useEffect, useCallback } from "react";
import {
    fetchCollection,
    addToCollection,
    updateDocument,
    deleteDocument,
} from "../../Firebase/firestore";
import InvoiceTable from "./InvoiceTable";
import InvoiceForm from "./InvoiceForm";
import "./styles/InvoiceHub.css";

const InvoiceHub = ({ userId }) => {
    const [state, setState] = useState({
        invoices: [],
        filteredInvoices: [],
        analytics: { totalInvoices: 0, unpaidInvoices: 0, overdueInvoices: 0 },
        loading: false,
        searchTerm: "",
        showForm: false,
        formState: {
            isEditing: false,
            invoice: {
                invoiceNumber: "",
                client: "",
                dateIssued: "",
                dueDate: "",
                status: "Unpaid",
                items: [{ description: "", quantity: 1, price: 0 }],
                total: 0,
            },
        },
    });

    const { invoices, filteredInvoices, analytics, loading, searchTerm, showForm, formState } =
        state;

    // Helper to update state in a cleaner way
    const updateState = (updates) => setState((prev) => ({ ...prev, ...updates }));

    // Fetch invoices for the user
    const loadInvoices = useCallback(async () => {
        if (!userId) return;
        updateState({ loading: true });
        try {
            const data = await fetchCollection(userId, "invoices");
            updateState({ invoices: data });
        } catch (error) {
            console.error("Error fetching invoices:", error.message);
            alert("Failed to fetch invoices.");
        } finally {
            updateState({ loading: false });
        }
    }, [userId]);

    // Calculate analytics
    const calculateAnalytics = useCallback((invoicesList) => {
        const totalInvoices = invoicesList.length;
        const unpaidInvoices = invoicesList.filter((inv) => inv.status === "Unpaid").length;
        const overdueInvoices = invoicesList.filter((inv) => {
            const today = new Date();
            const dueDate = new Date(inv.dueDate);
            return inv.status === "Unpaid" && dueDate < today;
        }).length;

        return { totalInvoices, unpaidInvoices, overdueInvoices };
    }, []);

    // Filter invoices based on search term
    const getFilteredInvoices = useCallback(
        (term, invoicesList) => {
            if (!term) return invoicesList;
            const lowerTerm = term.toLowerCase();
            return invoicesList.filter(
                (invoice) =>
                    invoice.client.toLowerCase().includes(lowerTerm) ||
                    invoice.status.toLowerCase().includes(lowerTerm)
            );
        },
        []
    );

    useEffect(() => {
        loadInvoices();
    }, [loadInvoices]);

    useEffect(() => {
        const filtered = getFilteredInvoices(searchTerm, invoices);
        const updatedAnalytics = calculateAnalytics(filtered);

        updateState({
            filteredInvoices: filtered,
            analytics: updatedAnalytics,
        });
    }, [invoices, searchTerm, calculateAnalytics, getFilteredInvoices]);

    const handleAddOrUpdate = async () => {
        const { invoiceNumber, client, dateIssued, dueDate, items } = formState.invoice;

        if (!invoiceNumber || !client || !dateIssued || !dueDate || items.length === 0) {
            alert("Please complete all fields.");
            return;
        }

        const total = items.reduce((sum, item) => sum + item.quantity * item.price, 0);
        const newInvoice = { ...formState.invoice, total };

        try {
            if (formState.isEditing) {
                await updateDocument(userId, "invoices", formState.invoice.id, newInvoice);
                alert("Invoice updated successfully!");
            } else {
                await addToCollection(userId, "invoices", newInvoice);
                alert("Invoice added successfully!");
            }
            resetForm();
            loadInvoices();
            updateState({ showForm: false });
        } catch (error) {
            console.error("Error saving invoice:", error.message);
            alert("Failed to save invoice.");
        }
    };

    const handleDelete = async (id) => {
        if (!window.confirm("Are you sure you want to delete this invoice?")) return;
        try {
            await deleteDocument(userId, "invoices", id);
            updateState({
                invoices: invoices.filter((invoice) => invoice.id !== id),
            });
            alert("Invoice deleted successfully!");
        } catch (error) {
            console.error("Error deleting invoice:", error.message);
            alert("Failed to delete invoice.");
        }
    };

    const resetForm = () => {
        updateState({
            formState: {
                isEditing: false,
                invoice: {
                    invoiceNumber: "",
                    client: "",
                    dateIssued: "",
                    dueDate: "",
                    status: "Unpaid",
                    items: [{ description: "", quantity: 1, price: 0 }],
                    total: 0,
                },
            },
        });
    };

    const handleToggleForm = () => {
        updateState({ showForm: !showForm });
        if (showForm) resetForm();
    };

    return (
        <div className="invoice-hub">
            <h2>Invoice Management</h2>

            {/* Tab Bar for Actions */}
            <div className="tab-bar">
                <input
                    type="text"
                    placeholder="Search by client or status..."
                    value={searchTerm}
                    onChange={(e) => updateState({ searchTerm: e.target.value })}
                    className="search-bar"
                />
                <button onClick={handleToggleForm} className="tab-button">
                    {showForm ? "Hide Form" : "Add Invoice"}
                </button>
            </div>

            {/* Analytics Section */}
            <div className="analytics">
                <p>Total Invoices: {analytics.totalInvoices}</p>
                <p>Unpaid Invoices: {analytics.unpaidInvoices}</p>
                <p>Overdue Invoices: {analytics.overdueInvoices}</p>
            </div>

            {/* Conditional Rendering of Invoice Form */}
            {showForm && (
                <InvoiceForm
                    formState={formState}
                    setFormState={(newState) => updateState({ formState: newState })}
                    onSave={handleAddOrUpdate}
                />
            )}

            {/* Invoice Table */}
            <InvoiceTable
                invoices={filteredInvoices}
                loading={loading}
                onEdit={(invoice) => {
                    updateState({
                        formState: { isEditing: true, invoice: { ...invoice } },
                        showForm: true,
                    });
                }}
                onDelete={handleDelete}
            />
        </div>
    );
};

export default InvoiceHub;
